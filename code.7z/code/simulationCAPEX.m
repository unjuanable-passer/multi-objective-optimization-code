function CAPEX = simulationCAPEX()
global Aspen
%CO2,SO2��NOx
Qr1=0.0041868*Aspen.Tree.FindNode("\Data\Blocks\T1\Output\REB_DUTY").Value;
Qr2=0.0041868*Aspen.Tree.FindNode("\Data\Blocks\T2\Output\REB_DUTY").Value;
Qr3=0.0041868*Aspen.Tree.FindNode("\Data\Blocks\T3\Output\REB_DUTY").Value;
Tr2=Aspen.Tree.FindNode("\Data\Blocks\T2\Output\BOTTOM_TEMP").Value;
Tr3=Aspen.Tree.FindNode("\Data\Blocks\T3\Output\BOTTOM_TEMP").Value;
%% MGAS��������gas emissions
CO2=(2.493)*(Qr1+Qr2+Qr3)/(0.92*29307.6)*8000;
SO2=(0.075)*(Qr1+Qr2+Qr3)/(0.92*29307.6)*8000;
NOX=(0.0375)*(Qr1+Qr2+Qr3)/(0.92*29307.6)*8000;
MGAS = CO2+SO2+NOX;
%%
if Tr2<180 && Tr3<180
    CAPEX=MGAS;
else
    CAPEX=MGAS;
end
end 

