  function OPEX =simulationOPEX()
global Aspen
Qc1=-0.0041868*Aspen.Tree.FindNode("\Data\Blocks\T1\Output\COND_DUTY").Value;
Qr1=0.0041868*Aspen.Tree.FindNode("\Data\Blocks\T1\Output\REB_DUTY").Value;
Qc2=-0.0041868*Aspen.Tree.FindNode("\Data\Blocks\T2\Output\COND_DUTY").Value;
Qr2=0.0041868*Aspen.Tree.FindNode("\Data\Blocks\T2\Output\REB_DUTY").Value;
Qc3=-0.0041868*Aspen.Tree.FindNode("\Data\Blocks\T3\Output\COND_DUTY").Value;
Qr3=0.0041868*Aspen.Tree.FindNode("\Data\Blocks\T3\Output\REB_DUTY").Value;
Qh1=-0.0041868*Aspen.Tree.FindNode("\Data\Blocks\B1\Output\QCALC").Value;
Tc1=Aspen.Tree.FindNode("\Data\Blocks\T1\Output\TOP_TEMP").Value;
Tr1=Aspen.Tree.FindNode("\Data\Blocks\T1\Output\BOTTOM_TEMP").Value;
Tc2=Aspen.Tree.FindNode("\Data\Blocks\T2\Output\TOP_TEMP").Value;
Tr2=Aspen.Tree.FindNode("\Data\Blocks\T2\Output\BOTTOM_TEMP").Value;
Tc3=Aspen.Tree.FindNode("\Data\Blocks\T3\Output\TOP_TEMP").Value;
Tr3=Aspen.Tree.FindNode("\Data\Blocks\T3\Output\BOTTOM_TEMP").Value;
%% stream
if 0<Tr1 && Tr1<160
    Cs1=7.78;
    Ar1=Qr1/((160-Tr1)*0.568); 
else if 160<Tr1 && Tr1<180
        Cs1=8.22;
        Ar1=Qr1/((183.85-Tr1)*0.568); 
    else
         Cs1=100000;
        Ar1=Qr1/((5000-Tr1)*0.568); 
    end
end

if 0<Tr2 && Tr2<160
    Cs2=7.78;
    Ar2=Qr2/((160-Tr2)*0.568);
else if 160<Tr2 && Tr2<180
        Cs2=8.22;
        Ar2=Qr2/((183.85-Tr2)*0.568);
    else 
         Cs2=100000;
        Ar2=Qr2/((5000-Tr2)*0.568);
    end
end
if 0<Tr3 && Tr3<160
    Cs3=7.78;
    Ar3=Qr3/((160-Tr3)*0.568);
else if 160<Tr3 && Tr3<180
        Cs3=8.22;
        Ar3=Qr3/((183.85-Tr3)*0.568);
    else 
         Cs3=100000;
        Ar3=Qr3/((5000-Tr3)*0.568);
    end
end
%% clod
if Tc2>42
    Cw2=0.354;
    deT2=((Tc2-32)-(Tc2-42))/log((Tc2-32)/(Tc2-42));
else if 15<Tc2 && Tc2<42
        Cw2=4.43;
        deT2=((Tc2-5)-(Tc2-15))/log((Tc2-5)/(Tc2-15));
    else
        Cw2=7.89;
        deT2=((Tc2+20)-(Tc2+10))/log((Tc2+20)/(Tc2+10));
    end
end
if Tc3>42
    Cw3=0.354;
    deT3=((Tc3-32)-(Tc3-42))/log((Tc3-32)/(Tc3-42));
else if 15<Tc3 && Tc3<42
        Cw3=4.43;
         deT3=((Tc3-5)-(Tc3-15))/log((Tc3-5)/(Tc3-15));
    else
        Cw3=7.89;
        deT3=((Tc3+20)-(Tc3+10))/log((Tc3+20)/(Tc3+10));
    end
end
CostSteam1=Qr1*8*3.6*Cs1;
CostSteam2=Qr2*8*3.6*Cs2;
CostSteam3=Qr3*8*3.6*Cs3;
CostWater1=Qc1*8*3.6*0.354;
CostWater2=Qc2*8*3.6*Cw2;
CostWater3=Qc3*8*3.6*Cw3;
CostWater4=Qh1*8*3.6*0.354;
CostSteam=CostSteam1+CostSteam2+CostSteam3;
CostWater=CostWater1+CostWater2+CostWater3+CostWater4;
%% T1
N1 = double(Aspen.Tree.FindNode("\Data\Blocks\T1\Input\NSTAGE").Value - 2);
H1=N1*0.61*1.2;
D1 = Aspen.Tree.FindNode("\Data\Blocks\T1\Input\CA_SUMP_DIAM\INT-1").Value;
CostT1=17640*(D1.^1.066)*(H1.^0.802);
deT1=((Tc1-32)-(Tc1-42))/log((Tc1-32)/(Tc1-42));
Ac1=Qc1/(deT1*0.852);   
Costc1=7296*Ac1.^0.65;
Costr1=7296*Ar1.^0.65;
Cost1=Costc1+Costr1+CostT1;
%% T2
N2 = double(Aspen.Tree.FindNode("\Data\Blocks\T2\Input\NSTAGE").Value - 2);
H2=N2*0.61*1.2;
D2 = Aspen.Tree.FindNode("\Data\Blocks\T2\Input\CA_SUMP_DIAM\INT-1").Value;
P2=Aspen.Tree.FindNode("\Data\Blocks\T2\Input\PRES1").Value;
CostT2=17640*(D2.^1.066) * (H2.^0.802); 
Ac2=Qc2/(deT2*0.852);
Costc2=7296*Ac2.^0.65;
Costr2=7296*Ar2.^0.65;
Cost2=Costc2+Costr2+CostT2;
%% T3
N3 = double(Aspen.Tree.FindNode("\Data\Blocks\T3\Input\NSTAGE").Value - 2);
H3=N3*0.61*1.2;
D3 = Aspen.Tree.FindNode("\Data\Blocks\T3\Input\CA_SUMP_DIAM\INT-1").Value;
P3=Aspen.Tree.FindNode("\Data\Blocks\T3\Input\PRES1").Value;
CostT3=17640*(D3.^1.066) * (H3.^0.802);
Ac3=Qc3/(deT3*0.852);
Costc3=7296*Ac3.^0.65;
Costr3=7296*Ar3.^0.65;
Cost3=Costc3+Costr3+CostT3;
%% H1
deh1=((Tr3-40)-8)/log((Tr3-40)/8);
Ah1=Qh1/(deh1*0.852);  
Costh1=7296*Ah1.^0.65;
%% Vacuum system cost
    V2=35.3*H2*3.14*((D2/2).^2);
    WW2=5+(0.0298+0.03088*(log(P2*760))-0.0005733*((log(P2*760)).^2))*(V2.^0.66);
    Vacuum2=1690*1.8*((WW2/P2).^0.41);
    V3=35.3*H3*3.14*((D3/2).^2);
    WW3=5+(0.0298+0.03088*(log(P3*760))-0.0005733*((log(P3*760)).^2))*(V3.^0.66);
    Vacuum3=1690*1.8*((WW3/P3).^0.41);
%% TCC
TCC=Cost1+Cost2+Cost3+Costh1;
TC=TCC/3;
TOC=CostSteam+CostWater+Vacuum2+Vacuum3;
OPEX=TOC+TC;


end
